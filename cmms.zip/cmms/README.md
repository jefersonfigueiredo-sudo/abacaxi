# CMMS – Escolas PPP

## Backend (porta 3000)
    docker compose up -d
    cd backend && cp .env.example .env && npm install && npm run start:dev

## Frontend (porta 5173, PWA mobile-first)
    cd frontend && npm install && npm run dev

Login inicial: ADMIN_EMAIL / ADMIN_PASSWORD do backend/.env.
Ajuste os prazos em /api/sla (PUT) ou direto na tabela sla_policies e as categorias em frontend/src/api.ts (CATEGORIES).

## Publicar online (gratuito)
1. Crie um banco no Neon (neon.com) e copie a connection string.
2. Suba este projeto para um repositório no GitHub.
3. No Render: New → Blueprint → selecione o repositório (usa render.yaml).
4. Preencha: DATABASE_URL (Neon), ADMIN_EMAIL, ADMIN_PASSWORD e, após o 1º deploy, FRONTEND_URL (URL do cmms-app) e VITE_API_URL (URL do cmms-api, sem /api final). Refaça o deploy do app.
