import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Navigate, NavLink, Outlet, Route, Routes } from 'react-router-dom';
import { AuthProvider, useAuth } from './auth';
import Login from './pages/Login';
import WorkOrders from './pages/WorkOrders';
import WorkOrderDetail from './pages/WorkOrderDetail';
import NewWorkOrder from './pages/NewWorkOrder';
import Dashboard from './pages/Dashboard';
import './styles.css';

function Layout() {
  const { user, logout } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  const manager = user.role === 'ADMIN' || user.role === 'MANAGER';
  return (
    <div className="app">
      <header><strong>CMMS Escolas</strong><span>{user.name}</span><button className="link" onClick={logout}>Sair</button></header>
      <main><Outlet /></main>
      <nav>
        <NavLink to="/" end>Chamados</NavLink>
        <NavLink to="/new">+ Novo</NavLink>
        {manager && <NavLink to="/dashboard">Painel</NavLink>}
      </nav>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode><AuthProvider><BrowserRouter><Routes>
    <Route path="/login" element={<Login />} />
    <Route element={<Layout />}>
      <Route index element={<WorkOrders />} />
      <Route path="new" element={<NewWorkOrder />} />
      <Route path="os/:id" element={<WorkOrderDetail />} />
      <Route path="dashboard" element={<Dashboard />} />
    </Route>
  </Routes></BrowserRouter></AuthProvider></React.StrictMode>,
);
