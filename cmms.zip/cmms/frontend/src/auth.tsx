import { createContext, ReactNode, useContext, useState } from 'react';
import { api, User } from './api';

type Ctx = { user: User | null; login: (e: string, p: string) => Promise<void>; logout: () => void };
const AuthCtx = createContext<Ctx>(null!);
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => JSON.parse(localStorage.getItem('user') || 'null'));
  const login = async (email: string, password: string) => {
    const r = await api('/auth/login', { method: 'POST', body: { email, password } });
    localStorage.setItem('token', r.accessToken); localStorage.setItem('user', JSON.stringify(r.user)); setUser(r.user);
  };
  const logout = () => { localStorage.clear(); setUser(null); };
  return <AuthCtx.Provider value={{ user, login, logout }}>{children}</AuthCtx.Provider>;
}
