import { useCallback, useEffect, useState } from 'react';

export type Role = 'ADMIN' | 'MANAGER' | 'TECHNICIAN' | 'REQUESTER';
export type User = { id: string; name: string; email: string; role: Role; schoolId: string | null };
export type WO = {
  id: string; number: number; title: string; description?: string; category?: string; priority: string; status: string; type: string;
  school?: { id: string; name: string }; asset?: { id: string; name: string; tag: string } | null;
  assignee?: { id: string; name: string } | null; requester?: { name: string };
  slaDueAt: string | null; slaResponseDueAt: string | null; startedAt: string | null; completedAt: string | null; resolution?: string | null; createdAt: string;
};

export const STATUS_PT: Record<string, string> = { OPEN: 'Aberta', ASSIGNED: 'Atribuída', IN_PROGRESS: 'Em andamento', ON_HOLD: 'Pausada', DONE: 'Concluída', CANCELLED: 'Cancelada' };
export const PRIORITY_PT: Record<string, string> = { LOW: 'Baixa', MEDIUM: 'Média', HIGH: 'Alta', URGENT: 'Urgente' };
// Ajustar conforme as categorias de serviço do contrato
export const CATEGORIES = ['Elétrica', 'Hidráulica', 'Ar-condicionado', 'Civil', 'Pintura', 'Cobertura', 'Segurança', 'Outros'];

export async function api<T = any>(path: string, opts: { method?: string; body?: unknown } = {}): Promise<T> {
  const token = localStorage.getItem('token');
  const res = await fetch((import.meta.env.VITE_API_URL ?? '') + '/api' + path, {
    method: opts.method ?? 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (res.status === 401 && path !== '/auth/login') { localStorage.clear(); location.href = '/login'; }
  if (!res.ok) {
    const e = await res.json().catch(() => ({}));
    throw new Error(Array.isArray(e.message) ? e.message.join(', ') : e.message ?? 'Erro na requisição');
  }
  return res.json();
}

export function useFetch<T>(path: string | null) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const reload = useCallback(() => {
    if (!path) return;
    setLoading(true);
    api<T>(path).then(setData).catch((e) => setError(e.message)).finally(() => setLoading(false));
  }, [path]);
  useEffect(reload, [reload]);
  return { data, error, loading, reload };
}

export function slaLabel(wo: WO) {
  if (!wo.slaDueAt || ['DONE', 'CANCELLED'].includes(wo.status)) return { text: '', late: false };
  const h = (new Date(wo.slaDueAt).getTime() - Date.now()) / 3600_000;
  if (h < 0) return { text: `SLA vencido há ${Math.ceil(-h)}h`, late: true };
  return { text: h < 48 ? `SLA: ${Math.floor(h)}h restantes` : `SLA: ${Math.floor(h / 24)}d restantes`, late: false };
}
