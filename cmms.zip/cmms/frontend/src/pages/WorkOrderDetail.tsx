import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { api, PRIORITY_PT, slaLabel, STATUS_PT, useFetch, User, WO } from '../api';
import { useAuth } from '../auth';

export default function WorkOrderDetail() {
  const { id } = useParams(); const { user } = useAuth();
  const { data: wo, error, reload } = useFetch<WO>(`/work-orders/${id}`);
  const manager = user?.role === 'ADMIN' || user?.role === 'MANAGER';
  const techs = useFetch<User[]>(manager ? '/users/technicians' : null);
  const [tech, setTech] = useState(''); const [resolution, setResolution] = useState('');
  const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false);

  const go = async (status: string, extra: object = {}) => {
    setBusy(true); setMsg('');
    try { await api(`/work-orders/${id}/status`, { method: 'PATCH', body: { status, ...extra } }); reload(); setResolution(''); }
    catch (e: any) { setMsg(e.message); } finally { setBusy(false); }
  };
  if (error) return <p className="err">{error}</p>;
  if (!wo) return <p className="muted">Carregando…</p>;
  const sla = slaLabel(wo); const s = wo.status; const field = user?.role === 'TECHNICIAN' || manager;

  return (
    <div className="card">
      <div className="row"><h2>#{wo.number}</h2><span className={`badge ${s}`}>{STATUS_PT[s]}</span></div>
      <h3>{wo.title}</h3>
      {wo.description && <p>{wo.description}</p>}
      <dl>
        <dt>Escola</dt><dd>{wo.school?.name}</dd>
        {wo.asset && (<><dt>Equipamento</dt><dd>{wo.asset.tag} – {wo.asset.name}</dd></>)}
        <dt>Categoria / Prioridade</dt><dd>{wo.category ?? '—'} · {PRIORITY_PT[wo.priority]}</dd>
        <dt>Solicitante</dt><dd>{wo.requester?.name}</dd>
        <dt>Responsável</dt><dd>{wo.assignee?.name ?? '—'}</dd>
        <dt>Prazo de resolução</dt><dd className={sla.late ? 'late' : ''}>{wo.slaDueAt ? new Date(wo.slaDueAt).toLocaleString('pt-BR') : '—'} {sla.text && `(${sla.text})`}</dd>
        {wo.resolution && (<><dt>Resolução</dt><dd>{wo.resolution}</dd></>)}
      </dl>
      {msg && <p className="err">{msg}</p>}

      {manager && s === 'OPEN' && (<>
        <select value={tech} onChange={(e) => setTech(e.target.value)}>
          <option value="">Atribuir a…</option>{techs.data?.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
        <button className="primary" disabled={!tech || busy} onClick={() => go('ASSIGNED', { assigneeId: tech })}>Atribuir técnico</button>
      </>)}
      {field && s === 'ASSIGNED' && <button className="primary" disabled={busy} onClick={() => go('IN_PROGRESS')}>Iniciar atendimento</button>}
      {field && s === 'ON_HOLD' && <button className="primary" disabled={busy} onClick={() => go('IN_PROGRESS')}>Retomar</button>}
      {field && s === 'IN_PROGRESS' && (<>
        <textarea rows={3} placeholder="O que foi feito? (obrigatório para concluir)" value={resolution} onChange={(e) => setResolution(e.target.value)} />
        <button className="primary" disabled={!resolution || busy} onClick={() => go('DONE', { resolution })}>Concluir</button>
        <button disabled={busy} onClick={() => go('ON_HOLD')}>Pausar</button>
      </>)}
      {!['DONE', 'CANCELLED'].includes(s) && <button className="danger" disabled={busy} onClick={() => confirm('Cancelar este chamado?') && go('CANCELLED')}>Cancelar chamado</button>}
    </div>
  );
}
