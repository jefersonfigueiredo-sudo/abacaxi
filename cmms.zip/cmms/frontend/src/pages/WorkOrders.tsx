import { useState } from 'react';
import { Link } from 'react-router-dom';
import { PRIORITY_PT, slaLabel, STATUS_PT, useFetch, WO } from '../api';

export default function WorkOrders() {
  const [status, setStatus] = useState('');
  const { data, loading, error } = useFetch<WO[]>('/work-orders' + (status ? `?status=${status}` : ''));
  return (
    <>
      <select value={status} onChange={(e) => setStatus(e.target.value)}>
        <option value="">Todos os status</option>
        {Object.entries(STATUS_PT).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
      </select>
      {loading && <p className="muted">Carregando…</p>}
      {error && <p className="err">{error}</p>}
      {data?.length === 0 && <p className="muted">Nenhum chamado.</p>}
      {data?.map((wo) => {
        const sla = slaLabel(wo);
        return (
          <Link key={wo.id} to={`/os/${wo.id}`} className="card wo">
            <div className="row"><strong>#{wo.number} {wo.title}</strong><span className={`badge ${wo.status}`}>{STATUS_PT[wo.status]}</span></div>
            <div className="muted">{wo.school?.name}{wo.asset ? ` · ${wo.asset.name}` : ''}</div>
            <div className="row"><span className={`prio ${wo.priority}`}>{PRIORITY_PT[wo.priority]}</span>{sla.text && <span className={sla.late ? 'late' : 'muted'}>{sla.text}</span>}</div>
          </Link>
        );
      })}
    </>
  );
}
