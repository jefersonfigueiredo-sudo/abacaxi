import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, CATEGORIES, PRIORITY_PT, useFetch } from '../api';
import { useAuth } from '../auth';

export default function NewWorkOrder() {
  const { user } = useAuth(); const nav = useNavigate();
  const requester = user?.role === 'REQUESTER';
  const [f, setF] = useState({ title: '', description: '', category: CATEGORIES[0], priority: 'MEDIUM', schoolId: user?.schoolId ?? '', assetId: '' });
  const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));
  const schools = useFetch<{ id: string; name: string }[]>(requester ? null : '/schools');
  const assets = useFetch<{ id: string; name: string; tag: string }[]>(f.schoolId ? `/assets?schoolId=${f.schoolId}` : null);

  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setError('');
    try {
      const body: any = { ...f }; if (!body.assetId) delete body.assetId; if (requester) delete body.schoolId;
      const wo = await api('/work-orders', { method: 'POST', body }); nav(`/os/${wo.id}`);
    } catch (err: any) { setError(err.message); setBusy(false); }
  };
  return (
    <form className="card" onSubmit={submit}>
      <h2>Novo chamado</h2>
      {!requester && (
        <select required value={f.schoolId} onChange={(e) => set('schoolId', e.target.value)}>
          <option value="">Escola…</option>{schools.data?.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      )}
      <input placeholder="Título (ex.: Ar-condicionado da sala 3 não gela)" value={f.title} onChange={(e) => set('title', e.target.value)} required />
      <textarea rows={4} placeholder="Descrição" value={f.description} onChange={(e) => set('description', e.target.value)} />
      <select value={f.category} onChange={(e) => set('category', e.target.value)}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
      <select value={f.priority} onChange={(e) => set('priority', e.target.value)}>{Object.entries(PRIORITY_PT).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
      <select value={f.assetId} onChange={(e) => set('assetId', e.target.value)}>
        <option value="">Equipamento (opcional)</option>{assets.data?.map((a) => <option key={a.id} value={a.id}>{a.tag} – {a.name}</option>)}
      </select>
      {error && <p className="err">{error}</p>}
      <button className="primary" disabled={busy}>{busy ? 'Enviando…' : 'Abrir chamado'}</button>
    </form>
  );
}
