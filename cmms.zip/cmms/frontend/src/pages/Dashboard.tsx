import { STATUS_PT, useFetch } from '../api';

type Stats = { byStatus: { status: string; total: string }[]; overdue: number; responseLate: number };

export default function Dashboard() {
  const { data, loading, error } = useFetch<Stats>('/work-orders/stats');
  if (loading) return <p className="muted">Carregando…</p>;
  if (error || !data) return <p className="err">{error}</p>;
  return (
    <>
      <h2>Painel</h2>
      <div className="grid">
        <div className="card kpi late"><b>{data.overdue}</b><span>SLA de resolução vencido</span></div>
        <div className="card kpi late"><b>{data.responseLate}</b><span>Sem atendimento no prazo</span></div>
        {data.byStatus.map((r) => <div key={r.status} className="card kpi"><b>{r.total}</b><span>{STATUS_PT[r.status]}</span></div>)}
      </div>
    </>
  );
}
