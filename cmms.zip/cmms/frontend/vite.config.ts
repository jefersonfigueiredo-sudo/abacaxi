import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [react(), VitePWA({ registerType: 'autoUpdate',
    manifest: { name: 'CMMS Escolas PPP', short_name: 'CMMS', display: 'standalone', theme_color: '#0b5fff', background_color: '#ffffff', start_url: '/' } })],
  server: { proxy: { '/api': 'http://localhost:3000' } },
});
