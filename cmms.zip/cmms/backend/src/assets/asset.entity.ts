import { Column, Entity, Index, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { School } from '../schools/school.entity';

export enum Criticality { LOW = 'LOW', MEDIUM = 'MEDIUM', HIGH = 'HIGH' }

@Entity('assets')
export class Asset {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Index({ unique: true }) @Column() tag: string;
  @Column() name: string;
  @Column({ nullable: true }) category: string;
  @Column({ nullable: true }) location: string;
  @Column({ type: 'enum', enum: Criticality, default: Criticality.MEDIUM }) criticality: Criticality;
  @Column({ default: true }) active: boolean;
  @ManyToOne(() => School, { nullable: false, onDelete: 'RESTRICT' }) school: School;
  @Column({ type: 'uuid' }) schoolId: string;
}
