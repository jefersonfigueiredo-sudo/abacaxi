import { Body, Controller, Get, Module, Post, Query } from '@nestjs/common';
import { InjectRepository, TypeOrmModule } from '@nestjs/typeorm';
import { IsEnum, IsOptional, IsString, IsUUID } from 'class-validator';
import { Repository } from 'typeorm';
import { Roles } from '../auth/guards';
import { Role } from '../users/user.entity';
import { Asset, Criticality } from './asset.entity';

class AssetDto {
  @IsString() tag: string;
  @IsString() name: string;
  @IsUUID() schoolId: string;
  @IsOptional() @IsString() category?: string;
  @IsOptional() @IsString() location?: string;
  @IsOptional() @IsEnum(Criticality) criticality?: Criticality;
}

@Controller('assets')
export class AssetsController {
  constructor(@InjectRepository(Asset) private repo: Repository<Asset>) {}
  @Get() list(@Query('schoolId') schoolId?: string) { return this.repo.find({ where: schoolId ? { schoolId } : {} }); }
  @Post() @Roles(Role.ADMIN, Role.MANAGER) create(@Body() d: AssetDto) { return this.repo.save(this.repo.create(d)); }
}

@Module({ imports: [TypeOrmModule.forFeature([Asset])], controllers: [AssetsController] })
export class AssetsModule {}
