import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { Asset } from '../assets/asset.entity';
import { School } from '../schools/school.entity';
import { User } from '../users/user.entity';

export enum WOType { CORRECTIVE = 'CORRECTIVE', PREVENTIVE = 'PREVENTIVE', PREDICTIVE = 'PREDICTIVE' }
export enum Priority { LOW = 'LOW', MEDIUM = 'MEDIUM', HIGH = 'HIGH', URGENT = 'URGENT' }
export enum WOStatus { OPEN = 'OPEN', ASSIGNED = 'ASSIGNED', IN_PROGRESS = 'IN_PROGRESS', ON_HOLD = 'ON_HOLD', DONE = 'DONE', CANCELLED = 'CANCELLED' }

@Entity('work_orders')
export class WorkOrder {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ type: 'int', generated: 'increment', unique: true }) number: number;
  @Column() title: string;
  @Column({ type: 'text', nullable: true }) description: string;
  @Column({ type: 'enum', enum: WOType, default: WOType.CORRECTIVE }) type: WOType;
  @Column({ type: 'enum', enum: Priority, default: Priority.MEDIUM }) priority: Priority;
  @Column({ type: 'enum', enum: WOStatus, default: WOStatus.OPEN }) status: WOStatus;

  @ManyToOne(() => School, { nullable: false }) school: School;
  @Column({ type: 'uuid' }) schoolId: string;
  @ManyToOne(() => Asset, { nullable: true }) asset: Asset | null;
  @Column({ type: 'uuid', nullable: true }) assetId: string | null;
  @ManyToOne(() => User, { nullable: false }) requester: User;
  @Column({ type: 'uuid' }) requesterId: string;
  @ManyToOne(() => User, { nullable: true }) assignee: User | null;
  @Column({ type: 'uuid', nullable: true }) assigneeId: string | null;

  @Column({ nullable: true }) category: string | null;
  @Column({ type: 'timestamptz', nullable: true }) slaResponseDueAt: Date | null;
  @Column({ type: 'timestamptz', nullable: true }) slaDueAt: Date | null;
  @Column({ type: 'timestamptz', nullable: true }) startedAt: Date | null;
  @Column({ type: 'timestamptz', nullable: true }) completedAt: Date | null;
  @Column({ type: 'text', nullable: true }) resolution: string | null;
  @CreateDateColumn() createdAt: Date;
  @UpdateDateColumn() updatedAt: Date;
}
