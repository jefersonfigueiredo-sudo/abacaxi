import { Body, Controller, Get, Module, Param, Patch, Post, Query, Req } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { IsEnum, IsOptional, IsString, IsUUID } from 'class-validator';
import { Roles } from '../auth/guards';
import { Role } from '../users/user.entity';
import { Priority, WorkOrder, WOStatus, WOType } from './work-order.entity';
import { SlaModule } from '../sla/sla.module';
import { WorkOrdersService } from './work-orders.service';

class CreateWODto {
  @IsString() title: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsEnum(WOType) type?: WOType;
  @IsOptional() @IsEnum(Priority) priority?: Priority;
  @IsOptional() @IsUUID() schoolId?: string;
  @IsOptional() @IsUUID() assetId?: string;
  @IsOptional() @IsString() category?: string;
}
class TransitionDto {
  @IsEnum(WOStatus) status: WOStatus;
  @IsOptional() @IsUUID() assigneeId?: string;
  @IsOptional() @IsString() resolution?: string;
}

@Controller('work-orders')
export class WorkOrdersController {
  constructor(private s: WorkOrdersService) {}
  @Post() create(@Req() r: any, @Body() d: CreateWODto) { return this.s.create(r.user, d); }
  @Get() list(@Req() r: any, @Query() q: any) { return this.s.list(r.user, q); }
  @Get('stats') @Roles(Role.ADMIN, Role.MANAGER) stats() { return this.s.stats(); }
  @Get(':id') one(@Req() r: any, @Param('id') id: string) { return this.s.findOne(r.user, id); }
  @Patch(':id/status')
  transition(@Req() r: any, @Param('id') id: string, @Body() d: TransitionDto) {
    return this.s.transition(r.user, id, d.status, d);
  }
}

@Module({ imports: [TypeOrmModule.forFeature([WorkOrder]), SlaModule], controllers: [WorkOrdersController], providers: [WorkOrdersService] })
export class WorkOrdersModule {}
