import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { SlaService } from '../sla/sla.module';
import { Role } from '../users/user.entity';
import { Priority, WorkOrder, WOStatus } from './work-order.entity';

type Actor = { id: string; role: Role; schoolId: string | null };

const TRANSITIONS: Record<WOStatus, WOStatus[]> = {
  OPEN: [WOStatus.ASSIGNED, WOStatus.CANCELLED],
  ASSIGNED: [WOStatus.IN_PROGRESS, WOStatus.CANCELLED],
  IN_PROGRESS: [WOStatus.ON_HOLD, WOStatus.DONE],
  ON_HOLD: [WOStatus.IN_PROGRESS, WOStatus.CANCELLED],
  DONE: [], CANCELLED: [],
};
const REL = { school: true, asset: true, assignee: true, requester: true };

@Injectable()
export class WorkOrdersService {
  constructor(@InjectRepository(WorkOrder) private repo: Repository<WorkOrder>, private sla: SlaService) {}

  async create(actor: Actor, d: Partial<WorkOrder>) {
    const schoolId = actor.role === Role.REQUESTER ? actor.schoolId : d.schoolId;
    if (!schoolId) throw new BadRequestException('Escola obrigatória');
    const priority = d.priority ?? Priority.MEDIUM;
    const h = await this.sla.hoursFor(d.category ?? undefined, priority);
    const now = Date.now();
    return this.repo.save(this.repo.create({
      ...d, schoolId, priority, requesterId: actor.id,
      slaResponseDueAt: new Date(now + h.responseHours * 3600_000),
      slaDueAt: new Date(now + h.resolutionHours * 3600_000),
    }));
  }

  list(actor: Actor, q: { schoolId?: string; status?: WOStatus; assigneeId?: string }) {
    const where: any = { ...q };
    if (actor.role === Role.REQUESTER) where.schoolId = actor.schoolId;
    if (actor.role === Role.TECHNICIAN) where.assigneeId = actor.id;
    return this.repo.find({ where, relations: REL, order: { createdAt: 'DESC' }, take: 200 });
  }

  async findOne(actor: Actor, id: string) {
    const wo = await this.repo.findOneOrFail({ where: { id }, relations: REL });
    if (actor.role === Role.REQUESTER && wo.schoolId !== actor.schoolId) throw new ForbiddenException();
    if (actor.role === Role.TECHNICIAN && wo.assigneeId !== actor.id) throw new ForbiddenException();
    return wo;
  }

  async transition(actor: Actor, id: string, to: WOStatus, extra: { assigneeId?: string; resolution?: string }) {
    const wo = await this.repo.findOneByOrFail({ id });
    if (actor.role === Role.TECHNICIAN && wo.assigneeId !== actor.id) throw new ForbiddenException();
    if (actor.role === Role.REQUESTER && to !== WOStatus.CANCELLED) throw new ForbiddenException();
    if (!TRANSITIONS[wo.status].includes(to)) throw new BadRequestException(`Transição inválida: ${wo.status} → ${to}`);
    if (to === WOStatus.ASSIGNED) {
      if (!extra.assigneeId) throw new BadRequestException('Informe o técnico responsável');
      wo.assigneeId = extra.assigneeId;
    }
    if (to === WOStatus.IN_PROGRESS && !wo.startedAt) wo.startedAt = new Date();
    if (to === WOStatus.DONE) {
      if (!extra.resolution) throw new BadRequestException('Informe a resolução');
      wo.resolution = extra.resolution; wo.completedAt = new Date();
    }
    wo.status = to;
    await this.repo.save(wo);
    return this.findOne({ ...actor, role: Role.ADMIN }, id);
  }

  async stats() {
    const byStatus = await this.repo.createQueryBuilder('w')
      .select('w.status', 'status').addSelect('COUNT(*)', 'total').groupBy('w.status').getRawMany();
    const open = { s: [WOStatus.DONE, WOStatus.CANCELLED] };
    const overdue = await this.repo.createQueryBuilder('w')
      .where('w.slaDueAt < now()').andWhere('w.status NOT IN (:...s)', open).getCount();
    const responseLate = await this.repo.createQueryBuilder('w')
      .where('w.slaResponseDueAt < now()').andWhere('w.startedAt IS NULL').andWhere('w.status NOT IN (:...s)', open).getCount();
    return { byStatus, overdue, responseLate };
  }
}
