import { Body, Controller, Post, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { IsEmail, IsString } from 'class-validator';
import * as bcrypt from 'bcrypt';
import { UsersService } from '../users/users.service';
import { Public } from './guards';

class LoginDto { @IsEmail() email: string; @IsString() password: string; }

@Controller('auth')
export class AuthController {
  constructor(private users: UsersService, private jwt: JwtService) {}

  @Public()
  @Post('login')
  async login(@Body() dto: LoginDto) {
    const u = await this.users.findByEmailWithHash(dto.email);
    if (!u || !u.active || !(await bcrypt.compare(dto.password, u.passwordHash)))
      throw new UnauthorizedException('Credenciais inválidas');
    const token = await this.jwt.signAsync({ sub: u.id, role: u.role, schoolId: u.schoolId });
    return { accessToken: token, user: { id: u.id, name: u.name, email: u.email, role: u.role, schoolId: u.schoolId } };
  }
}
