import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { APP_GUARD } from '@nestjs/core';
import { UsersModule } from './users/users.module';
import { AuthModule } from './auth/auth.module';
import { SchoolsModule } from './schools/schools.module';
import { AssetsModule } from './assets/assets.module';
import { WorkOrdersModule } from './work-orders/work-orders.module';
import { JwtAuthGuard, RolesGuard } from './auth/guards';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (c: ConfigService) => ({
        type: 'postgres',
        ...(c.get('DATABASE_URL')
          ? { url: c.get('DATABASE_URL'), ssl: true } // Neon/hospedagem exige SSL
          : { host: c.get('DB_HOST'), port: +c.get('DB_PORT'), username: c.get('DB_USER'), password: c.get('DB_PASS'), database: c.get('DB_NAME') }),
        autoLoadEntities: true,
        synchronize: true, // pilot/demo; em produção use migrations
      }),
    }),
    UsersModule, AuthModule, SchoolsModule, AssetsModule, WorkOrdersModule,
  ],
  providers: [
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
  ],
})
export class AppModule {}
