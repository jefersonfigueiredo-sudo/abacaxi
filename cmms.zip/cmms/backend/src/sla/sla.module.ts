import { Body, Controller, Get, Injectable, Module, OnModuleInit, Put } from '@nestjs/common';
import { InjectRepository, TypeOrmModule } from '@nestjs/typeorm';
import { IsEnum, IsInt, IsOptional, IsString, Min } from 'class-validator';
import { Column, Entity, PrimaryGeneratedColumn, Repository, Unique } from 'typeorm';
import { Roles } from '../auth/guards';
import { Role } from '../users/user.entity';
import { Priority } from '../work-orders/work-order.entity';

// category '' = política padrão (vale para qualquer categoria sem regra própria)
@Entity('sla_policies')
@Unique(['category', 'priority'])
export class SlaPolicy {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ default: '' }) category: string;
  @Column({ type: 'enum', enum: Priority }) priority: Priority;
  @Column({ type: 'int' }) responseHours: number;   // prazo para iniciar o atendimento
  @Column({ type: 'int' }) resolutionHours: number; // prazo para concluir
}

class SlaDto {
  @IsOptional() @IsString() category?: string;
  @IsEnum(Priority) priority: Priority;
  @IsInt() @Min(1) responseHours: number;
  @IsInt() @Min(1) resolutionHours: number;
}

@Injectable()
export class SlaService implements OnModuleInit {
  constructor(@InjectRepository(SlaPolicy) private repo: Repository<SlaPolicy>) {}

  async onModuleInit() { // valores PROVISÓRIOS: substituir pelos do contrato da PPP
    if (await this.repo.count()) return;
    const d: [Priority, number, number][] = [[Priority.URGENT, 1, 4], [Priority.HIGH, 4, 24], [Priority.MEDIUM, 8, 72], [Priority.LOW, 24, 168]];
    await this.repo.save(d.map(([priority, responseHours, resolutionHours]) => this.repo.create({ category: '', priority, responseHours, resolutionHours })));
  }

  async hoursFor(category: string | undefined, priority: Priority) {
    const cat = category ?? '';
    const rows = await this.repo.find({ where: [{ category: cat, priority }, { category: '', priority }] });
    return rows.find((r) => r.category === cat) ?? rows[0] ?? { responseHours: 24, resolutionHours: 72 };
  }
  list() { return this.repo.find({ order: { category: 'ASC', priority: 'ASC' } }); }
  async save(d: SlaDto) { await this.repo.upsert({ ...d, category: d.category ?? '' }, ['category', 'priority']); return this.list(); }
}

@Controller('sla')
export class SlaController {
  constructor(private s: SlaService) {}
  @Get() list() { return this.s.list(); }
  @Put() @Roles(Role.ADMIN, Role.MANAGER) save(@Body() d: SlaDto) { return this.s.save(d); }
}

@Module({ imports: [TypeOrmModule.forFeature([SlaPolicy])], controllers: [SlaController], providers: [SlaService], exports: [SlaService] })
export class SlaModule {}
