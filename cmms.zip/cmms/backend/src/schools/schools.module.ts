import { Body, Controller, Get, Module, Param, Patch, Post } from '@nestjs/common';
import { InjectRepository, TypeOrmModule } from '@nestjs/typeorm';
import { IsOptional, IsString } from 'class-validator';
import { Repository } from 'typeorm';
import { Roles } from '../auth/guards';
import { Role } from '../users/user.entity';
import { School } from './school.entity';

class SchoolDto {
  @IsString() code: string;
  @IsString() name: string;
  @IsOptional() @IsString() city?: string;
  @IsOptional() @IsString() address?: string;
  @IsOptional() @IsString() region?: string;
}

@Controller('schools')
export class SchoolsController {
  constructor(@InjectRepository(School) private repo: Repository<School>) {}
  @Get() list() { return this.repo.find({ order: { name: 'ASC' } }); }
  @Get(':id') one(@Param('id') id: string) { return this.repo.findOneByOrFail({ id }); }
  @Post() @Roles(Role.ADMIN, Role.MANAGER) create(@Body() d: SchoolDto) { return this.repo.save(this.repo.create(d)); }
  @Patch(':id') @Roles(Role.ADMIN, Role.MANAGER)
  async update(@Param('id') id: string, @Body() d: Partial<SchoolDto>) { await this.repo.update(id, d); return this.one(id); }
}

@Module({ imports: [TypeOrmModule.forFeature([School])], controllers: [SchoolsController] })
export class SchoolsModule {}
