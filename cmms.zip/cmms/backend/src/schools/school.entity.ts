import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('schools')
export class School {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column({ unique: true }) code: string;
  @Column() name: string;
  @Column({ nullable: true }) city: string;
  @Column({ nullable: true }) address: string;
  @Column({ nullable: true }) region: string;
  @Column({ default: true }) active: boolean;
}
