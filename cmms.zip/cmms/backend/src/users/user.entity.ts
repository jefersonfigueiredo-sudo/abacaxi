import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

export enum Role { ADMIN = 'ADMIN', MANAGER = 'MANAGER', TECHNICIAN = 'TECHNICIAN', REQUESTER = 'REQUESTER' }

@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid') id: string;
  @Column() name: string;
  @Column({ unique: true }) email: string;
  @Column({ select: false }) passwordHash: string;
  @Column({ type: 'enum', enum: Role, default: Role.REQUESTER }) role: Role;
  @Column({ type: 'uuid', nullable: true }) schoolId: string | null;
  @Column({ default: true }) active: boolean;
  @CreateDateColumn() createdAt: Date;
}
