import { ConflictException, Injectable, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { Role, User } from './user.entity';

@Injectable()
export class UsersService implements OnModuleInit {
  constructor(@InjectRepository(User) private repo: Repository<User>, private cfg: ConfigService) {}

  async onModuleInit() {
    if ((await this.repo.count()) === 0) {
      await this.create({ name: 'Administrador', email: this.cfg.get('ADMIN_EMAIL')!,
        password: this.cfg.get('ADMIN_PASSWORD')!, role: Role.ADMIN });
    }
  }

  async create(d: { name: string; email: string; password: string; role: Role; schoolId?: string }) {
    if (await this.repo.findOneBy({ email: d.email })) throw new ConflictException('E-mail já cadastrado');
    const { password, ...rest } = d;
    const passwordHash = await bcrypt.hash(password, 10);
    const u: any = await this.repo.save(this.repo.create({ ...rest, passwordHash }));
    delete u.passwordHash;
    return u;
  }

  findAll() { return this.repo.find(); }
  findTechnicians() { return this.repo.find({ where: { role: Role.TECHNICIAN, active: true } }); }

  findByEmailWithHash(email: string) {
    return this.repo.createQueryBuilder('u').addSelect('u.passwordHash').where('u.email = :email', { email }).getOne();
  }
}
