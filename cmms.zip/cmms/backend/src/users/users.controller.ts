import { Body, Controller, Get, Post } from '@nestjs/common';
import { IsEmail, IsEnum, IsOptional, IsString, IsUUID, MinLength } from 'class-validator';
import { Roles } from '../auth/guards';
import { Role } from './user.entity';
import { UsersService } from './users.service';

class CreateUserDto {
  @IsString() name: string;
  @IsEmail() email: string;
  @MinLength(8) password: string;
  @IsEnum(Role) role: Role;
  @IsOptional() @IsUUID() schoolId?: string;
}

@Controller('users')
@Roles(Role.ADMIN)
export class UsersController {
  constructor(private s: UsersService) {}
  @Get('technicians') @Roles(Role.ADMIN, Role.MANAGER) technicians() { return this.s.findTechnicians(); }
  @Get() list() { return this.s.findAll(); }
  @Post() create(@Body() dto: CreateUserDto) { return this.s.create(dto); }
}
